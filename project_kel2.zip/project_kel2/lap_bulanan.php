<?php include "koneksi.php"; ?>

<?php
    $sqlquery = "SELECT * FROM laporan_sekolah";
    
    // Proses pencarian jika kata kunci disubmit
    if (isset($_GET['search'])) {
        $search = $koneksi->real_escape_string($_GET['search']);
        $sqlquery .= " WHERE nama LIKE '%$search%' OR spp LIKE '%$search%' OR nilai_tertinggi LIKE '%$search%' OR siswa_unggulan LIKE '%$search%'";
    }

    $hasil = $koneksi->query($sqlquery);
?>

<html>
<head>
    <title>Laporan Bulanan</title>
    <style>
      table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #007BFF;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #007BFF;
            color: white;
        }

        a {
            text-decoration: none;
            margin: 5px;
        }
    </style>
</head>
<body>

    <form action="" method="get">
        <label for="search">Cari:</label>
        <input type="text" id="search" name="search" placeholder="Masukkan kata kunci">
        <button type="submit">Cari</button>
    </form>

    <table border="1">
        <tr>
            <th>id</th>
            <th>nama</th>
            <th>spp</th>
            <th>nilai_tertinggi</th>
            <th>siswa_unggulan</th>
        </tr>

        <?php
            if ($hasil->num_rows > 0) {
                while ($baris = $hasil->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $baris["id"] . "</td>";
                    echo "<td>" . $baris["nama"] . "</td>";
                    echo "<td>" . $baris["spp"] . "</td>";
                    echo "<td>" . $baris["nilai_tertinggi"] . "</td>";
                    echo "<td>" . $baris["siswa_unggulan"] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "0 results";
            }
        ?>              
    </table>
    <a href="main_menu.html">Kembali</a>
</body>
</html>
