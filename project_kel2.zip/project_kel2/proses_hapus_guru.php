<?php include "koneksi.php"; ?>
<html>
    <head>
        <title>Proses Hapus Data Guru </title>
    </head>
<?php
$id = $_POST['id'];
?>

<?php
    $sqlquery = "delete from guru where id = ".$id.";";
    $hasil = $koneksi->query($sqlquery);
?>
    <body>
        <p>Data Berhasil Dihapus</p>
        <a href="tbl_guru.php">Kembali</a>
    </body>
</html>