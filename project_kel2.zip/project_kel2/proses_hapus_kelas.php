<?php include "koneksi.php"; ?>
<html>
    <head>
        <title>Proses Hapus Data Kelas </title>
    </head>
<?php
$id = $_POST['id'];
?>

<?php
    $sqlquery = "delete from kelas where id = ".$id.";";
    $hasil = $koneksi->query($sqlquery);
?>
    <body>
        <p>Data Berhasil Dihapus</p>
        <a href="tbl_kelas.php">Kembali</a>
    </body>
</html>