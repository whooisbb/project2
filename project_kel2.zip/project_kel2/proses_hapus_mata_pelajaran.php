<?php include "koneksi.php"; ?>
<html>
    <head>
        <title>Proses Hapus Data mata pelajaran </title>
    </head>
<?php
$id = $_POST['id'];
?>

<?php
    $sqlquery = "delete from mata_pelajaran where id = ".$id.";";
    $hasil = $koneksi->query($sqlquery);
?>
    <body>
        <p>Data Berhasil Dihapus</p>
        <a href="tbl_mata_pelajaran.php">Kembali</a>
    </body>
</html>