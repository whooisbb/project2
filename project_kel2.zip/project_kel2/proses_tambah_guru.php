<?php
include "koneksi.php";
?>

<html>
   <head>
        <title>Proses Tambah guru</title>
   </head>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $alamat = $_POST['alamat'];

    $sqlquery = "insert INTO guru (id, nama, tanggal_lahir, alamat) VALUES (?, ?, ?, ?)";
    $stmt = $koneksi->prepare($sqlquery);
    $stmt->bind_param("isss",$id, $nama, $tanggal_lahir, $alamat); 

    if ($stmt->execute()) {
        echo "Penambahan Berhasil";
    } else {

        echo "Penambahan Gagal: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Invalid request method.";
}
?>
<body>
     <a href="tbl_guru.php">Kembali</a>
</body>
</html>
