<?php
include "koneksi.php";
?>

<html>
   <head>
        <title>Proses Tambah jadwal</title>
   </head>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $id_kelas = $_POST['id_kelas'];
    $id_mata_pelajaran = $_POST['id_mata_pelajaran'];
    $id_guru = $_POST['id_guru'];
    $hari = $_POST['hari'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_selesai = $_POST['jam_selesai'];


    $sqlquery = "INSERT INTO jadwal_pelajaran (id, id_kelas, id_mata_pelajaran, id_guru, hari, jam_mulai, jam_selesai) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $koneksi->prepare($sqlquery);
    $stmt->bind_param("isissss", $id, $id_kelas, $id_mata_pelajaran, $id_guru, $hari, $jam_mulai, $jam_selesai);

    if ($stmt->execute()) {
 
        echo "Penambahan Berhasil";
    } else {
    
        echo "Penambahan Gagal: " . $koneksi->error;
    }

    $stmt->close();
} else {
    echo "Invalid request method.";
}
?>
<body>
     <a href="tbl_jadwal_pelajaran.php">Kembali</a>
</body>
</html>
