<?php
include "koneksi.php";
?>

<html>
   <head>
        <title>Proses Tambah kelas</title>
   </head>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $tingkat = $_POST['tingkat'];

    $sqlquery = "INSERT INTO kelas (id, nama, tingkat) VALUES (?, ?, ?)";
    $stmt = $koneksi->prepare($sqlquery);
    $stmt->bind_param("iss", $id, $nama, $tingkat); 
    if ($stmt->execute()) {
      
        echo "Penambahan Berhasil";
    } else {
      
        echo "Penambahan Gagal: " . $koneksi->error;
    }

    $stmt->close();
} else {
    echo "Invalid request method.";
}
?>
<body>
     <a href="tbl_kelas.php">Kembali</a>
</body>
</html>
