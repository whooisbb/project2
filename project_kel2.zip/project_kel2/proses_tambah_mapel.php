<?php
include "koneksi.php";
?>

<html>
   <head>
        <title>Proses Tambah mapel</title>
   </head>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $deskripsi = $_POST['deskripsi'];


    $sqlquery = "INSERT INTO mata_pelajaran (id, nama, deskripsi) VALUES (?, ?, ?)";
    $stmt = $koneksi->prepare($sqlquery);
    $stmt->bind_param("iss", $id, $nama, $deskripsi); 

    if ($stmt->execute()) {

        echo "Penambahan Berhasil";
    } else {

        echo "Penambahan Gagal: " . $koneksi->error;
    }

    $stmt->close();
} else {
    echo "Invalid request method.";
}
?>
<body>
     <a href="tbl_mata_pelajaran.php">Kembali</a>
</body>
</html>
