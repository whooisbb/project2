<?php
include "koneksi.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $alamat = $_POST['alamat'];

    $sqlquery = "INSERT INTO siswa (id, nama, tanggal_lahir, alamat) VALUES (?, ?, ?, ?)";
    $stmt = $koneksi->prepare($sqlquery);
    

    if ($stmt) {
        $stmt->bind_param("isss", $id, $nama, $tanggal_lahir, $alamat); 
        if ($stmt->execute()) {

            echo "Penambahan Berhasil";
        } else {

            echo "Penambahan Gagal: " . $stmt->error;
        }
        $stmt->close();
    } else {
   
        echo "Penambahan Gagal: " . $koneksi->error;
    }
} else {
    echo "Invalid request method.";
}
?>

<html>
   <head>
        <title>Proses Tambah Siswa</title>
   </head>
<body>
     <a href="tbl_siswa.php">Kembali</a>
</body>
</html>
