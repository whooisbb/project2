<?php
include "koneksi.php";

$id = $_POST['id'];
$nama = $_POST['nama'];
$tanggal_lahir = $_POST['tanggal_lahir'];
$alamat = $_POST['alamat'];

if (isset($id) && isset($nama) && isset($tanggal_lahir) && isset($alamat)) {
   
    $sqlquery = "UPDATE guru SET alamat = ?, tanggal_lahir = ?, nama = ? WHERE id = ?";
    $stmt = $koneksi->prepare($sqlquery);
    $stmt->bind_param("sssi", $alamat, $tanggal_lahir, $nama, $id);

    if ($stmt->execute()) {
     
        echo "Update Berhasil";
    } else {
 
        echo "Update Gagal: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Data tidak lengkap. Harap isi semua kolom.";
}
?>
<html>
    <head>
        <title>Proses Update guru</title>
    </head>
    <body>
        <a href="tbl_guru.php">Kembali</a>
    </body>
</html>
