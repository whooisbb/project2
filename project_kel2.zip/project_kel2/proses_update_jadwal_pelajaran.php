<?php
include "koneksi.php";

$id = $_POST['id'];
$id_kelas = $_POST['id_kelas'];
$id_mata_pelajaran = $_POST['id_mata_pelajaran'];
$id_guru = $_POST['id_guru'];
$hari = $_POST['hari'];
$jam_mulai = $_POST['jam_mulai'];
$jam_selesai = $_POST['jam_selesai'];

if (isset($id) && isset($id_kelas) && isset($id_mata_pelajaran) && isset($id_guru) && isset($hari) && isset($jam_mulai) && isset($jam_selesai)) {
   
    $sqlquery = "UPDATE jadwal_pelajaran SET jam_selesai = ?, jam_mulai = ?, hari = ?, id_guru = ?, id_mata_pelajaran = ?, id_kelas = ? WHERE id = ?";
    $stmt = $koneksi->prepare($sqlquery);
    $stmt->bind_param("sssiisi", $jam_selesai, $jam_mulai, $hari, $id_guru, $id_mata_pelajaran, $id_kelas, $id);

    if ($stmt->execute()) {
      
        echo "Update Berhasil";
    } else {
     
        echo "Update Gagal: " . $koneksi->error;
    }

    $stmt->close();
} else {
    echo "Data tidak lengkap. Harap isi semua kolom.";
}
?>
<html>
    <head>
        <title>Proses Update jadwal_pelajaran---</title>
    </head>
    <body>
        <a href="tbl_jadwal_pelajaran.php">Kembali</a>
    </body>
</html>
