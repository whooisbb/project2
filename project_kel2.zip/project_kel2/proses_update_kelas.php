<?php
include "koneksi.php";

$id = $_POST['id'];
$nama = $_POST['nama'];
$tingkat = $_POST['tingkat'];

if (isset($id) && isset($nama) && isset($tingkat)) {

    $sqlquery = "UPDATE kelas SET nama = ?, tingkat = ? WHERE id = ?";
    $stmt = $koneksi->prepare($sqlquery);
    $stmt->bind_param("ssi", $nama, $tingkat, $id);

    if ($stmt->execute()) {

        echo "Update Berhasil";
    } else {
   
        echo "Update Gagal: " . $koneksi->error;
    }

    $stmt->close();
} else {
    echo "Data tidak lengkap. Harap isi semua kolom.";
}
?>
<html>
    <head>
        <title>Proses Update kelas ---</title>
    </head>
    <body>
        <a href="tbl_kelas.php">Kembali</a>
    </body>
</html>
