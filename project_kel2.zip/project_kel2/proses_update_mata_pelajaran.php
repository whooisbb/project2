<?php
include "koneksi.php";

$id = $_POST['id'];
$nama = $_POST['nama'];
$deskripsi = $_POST['deskripsi'];

if (isset($id) && isset($nama) && isset($deskripsi)) {

    $sqlquery = "UPDATE mata_pelajaran SET nama = ?, deskripsi = ? WHERE id = ?";
    $stmt = $koneksi->prepare($sqlquery);
    $stmt->bind_param("ssi", $nama, $deskripsi, $id);

    if ($stmt->execute()) {
      
        echo "Update Berhasil";
    } else {
       
        echo "Update Gagal: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Data tidak lengkap. Harap isi semua kolom.";
}
?>
<html>
    <head>
        <title>Proses Update mata pelajaran ---</title>
    </head>
    <body>
        <a href="tbl_mata_pelajaran.php">Kembali</a>
    </body>
</html>
