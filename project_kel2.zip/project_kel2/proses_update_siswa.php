<?php
include "koneksi.php";

$id = $_POST['id'];
$nama = $_POST['nama'];
$tanggal_lahir = $_POST['tanggal_lahir'];
$alamat = $_POST['alamat'];

if (isset($id) && isset($nama) && isset($tanggal_lahir) && isset($alamat)) {

    $sqlquery = "UPDATE siswa SET nama = ?, tanggal_lahir = ?, alamat = ? WHERE id = ?";
    $stmt = $koneksi->prepare($sqlquery);
    $stmt->bind_param("sssi", $nama, $tanggal_lahir, $alamat, $id);

    if ($stmt->execute()) {

        echo "Update Berhasil";
    } else {
      
        echo "Update Gagal: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Data tidak lengkap. Harap isi semua kolom.";
}
?>
<html>
    <head>
        <title>Proses Update siswa ---</title>
    </head>
    <body>
        <a href="tbl_siswa.php">Kembali</a>
    </body>
</html>
