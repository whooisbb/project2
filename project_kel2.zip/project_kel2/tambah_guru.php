<!DOCTYPE html>
<html>
<head>
    <title>Form Tambah guru</title>
</head>
<body>
    <form action="proses_tambah_guru.php" method="POST">
        <p>id: </p> <input type="number" name="id">
        <p>Nama: </p> <input type="text" name="nama">
        <p>Tanggal Lahir: </p> <input type="date" name="tanggal_lahir">
        <p>Alamat: </p> <input type="text" name="alamat">

        <input type="submit" value="Tambah Data">
    </form>
</body>
</html>
