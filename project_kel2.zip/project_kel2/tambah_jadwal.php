<!DOCTYPE html>
<html>
<head>
    <title>Form Tambah Jadwal</title>
</head>
<body>
    <form action="proses_tambah_jadwal.php" method="POST">
        <p>id: </p> <input type="number" name="id">
        <p>id_kelas: </p> <input type="text" name="id_kelas">
        <p>id_mata_pelajaran: </p> <input type="number" name="id_mata_pelajaran">
        <p>id_guru: </p> <input type="number" name="id_guru">
        <p>hari: </p> <input type="text" name="hari">
        <p>jam_mulai: </p> <input type="time" name="jam_mulai">
        <p>jam_selesai: </p> <input type="time" name="jam_selesai">

        <input type="submit" value="Tambah Data">
    </form>
</body>
</html>
