<!DOCTYPE html>
<html>
<head>
    <title>Form Tambah kelas</title>
</head>
<body>
    <form action="proses_tambah_kelas.php" method="POST">
        <p>id: </p> <input type="number" name="id">
        <p>nama: </p> <input type="text" name="nama">
        <p>tingkat: </p> <input type="number" name="tingkat">

        <input type="submit" value="Tambah Data">
    </form>
</body>
</html>
