<!DOCTYPE html>
<html>
<head>
    <title>Form Tambah mapel</title>
</head>
<body>
    <form action="proses_tambah_mapel.php" method="POST">
        <p>id: </p> <input type="number" name="id">
        <p>nama: </p> <input type="text" name="nama">
        <p>Deskripsi: </p> <input type="text" name="deskripsi">

        <input type="submit" value="Tambah Data">
    </form>
</body>
</html>
