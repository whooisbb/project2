<?php
include "koneksi.php";

// Mengecek apakah form pencarian telah di-submit
if (isset($_GET['cari'])) {
    $keyword = $_GET['cari'];
    $sqlquery = "SELECT * FROM jadwal_pelajaran WHERE 
                  id_kelas LIKE '%$keyword%' OR 
                  id_mata_pelajaran LIKE '%$keyword%' OR 
                  id_guru LIKE '%$keyword%' OR 
                  hari LIKE '%$keyword%' OR 
                  jam_mulai LIKE '%$keyword%' OR 
                  jam_selesai LIKE '%$keyword%'";
} else {
    $sqlquery = "SELECT * FROM jadwal_pelajaran";
}

$hasil = $koneksi->query($sqlquery);
?>

<html>
<head>
    <title>jadwal pelajaran </title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #007BFF;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #007BFF;
            color: white;
        }

        a {
            text-decoration: none;
            margin: 5px;
        }
    </style>
</head>
<body>
    <!-- Form pencarian -->
    <form action="" method="get">
        <label for="cari">Cari:</label>
        <input type="text" id="cari" name="cari">
        <input type="submit" value="Cari">
    </form>

    <table border="1">
        <tr>
            <th>id</th>
            <th>id_kelas</th>
            <th>id_mata_pelajaran</th>
            <th>id_guru</th>
            <th>hari</th>
            <th>jam_mulai</th>
            <th>jam_selesai</th>
        </tr>
        <?php
        if ($hasil && $hasil->num_rows > 0) {
            while ($baris = $hasil->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $baris["id"] . "</td>";
                echo "<td>" . $baris["id_kelas"] . "</td>";
                echo "<td>" . $baris["id_mata_pelajaran"] . "</td>";
                echo "<td>" . $baris["id_guru"] . "</td>";
                echo "<td>" . $baris["hari"] . "</td>";
                echo "<td>" . $baris["jam_mulai"] . "</td>";
                echo "<td>" . $baris["jam_selesai"] . "</td>";
                echo "<td>" . "<form action='update_jadwal_pelajaran.php' method='POST'>";
                echo "<input type='submit' value='Update'>";
                echo "<input type='hidden' value='" . $baris["id"] . "' name='id'>";
                echo "</form>" . "</td>";
                echo "<td>" . "<form action='proses_hapus_jadwal.php' method='POST'>";
                echo "<input type='submit' value='Delete'>";
                echo "<input type='hidden' value='" . $baris["id"] . "' name='id'>";
                echo "</form>" . "</td>";
                echo "</tr>";
            }
        } else {
            echo "0 hasil ditemukan.";
        }
        ?>
    </table>
    <a href="main_menu.html">Kembali</a>
    <a href="tambah_jadwal.php">Tambah jadwal</a>
</body>
</html>
