<?php
include "koneksi.php";

// Mengecek apakah form pencarian telah di-submit
if (isset($_GET['cari'])) {
    $keyword = $_GET['cari'];
    $sqlquery = "SELECT * FROM kelas WHERE nama LIKE '%$keyword%' OR tingkat LIKE '%$keyword%'";
} else {
    $sqlquery = "SELECT * FROM kelas";
}

$hasil = $koneksi->query($sqlquery);
?>

<html>
<head>
    <title>Kelas </title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #007BFF;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #007BFF;
            color: white;
        }

        a {
            text-decoration: none;
            margin: 5px;
        }
    </style>
</head>
<body>
    <!-- Form pencarian -->
    <form action="" method="get">
        <label for="cari">Cari:</label>
        <input type="text" id="cari" name="cari">
        <input type="submit" value="Cari">
    </form>

    <table border="1">
        <tr>
            <th>id</th>
            <th>nama</th>
            <th>tingkat</th>
        </tr>
        <?php
        if ($hasil && $hasil->num_rows > 0) {
            while ($baris = $hasil->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $baris["id"] . "</td>";
                echo "<td>" . $baris["nama"] . "</td>";
                echo "<td>" . $baris["tingkat"] . "</td>";
                echo "<td>" . "<form action='update_kelas.php' method='POST'>";
                echo "<input type='submit' value='Update'>";
                echo "<input type='hidden' value='" . $baris["id"] . "' name='id'>";
                echo "</form>" . "</td>";
                echo "<td>" . "<form action='proses_hapus_kelas.php' method='POST'>";
                echo "<input type='submit' value='Delete'>";
                echo "<input type='hidden' value='" . $baris["id"] . "' name='id'>";
                echo "</form>" . "</td>";
                echo "</tr>";
            }
        } else {
            echo "0 hasil ditemukan.";
        }
        ?>
    </table>
    <a href="main_menu.html">Kembali</a>
    <a href="tambah_kelas.php">Tambah kelas</a>
</body>
</html>
