<?php
include "koneksi.php";


if (isset($_GET['cari'])) {
    $keyword = $_GET['cari'];
    $sqlquery = "SELECT * FROM mata_pelajaran WHERE nama LIKE '%$keyword%' OR deskripsi LIKE '%$keyword%'";
} else {
    $sqlquery = "SELECT * FROM mata_pelajaran";
}

$hasil = $koneksi->query($sqlquery);
?>

<html>
<head>
    <title>mata pelajaran</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #007BFF;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #007BFF;
            color: white;
        }

        a {
            text-decoration: none;
            margin: 5px;
        }
    </style>
</head>
<body>
   
    <form action="" method="get">
        <label for="cari">Cari:</label>
        <input type="text" id="cari" name="cari">
        <input type="submit" value="Cari">
    </form>

    <table border="1">
        <tr>
            <th>id</th>
            <th>nama</th>
            <th>deskripsi</th>
        </tr>
        <?php
        if ($hasil && $hasil->num_rows > 0) {
            while ($baris = $hasil->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $baris["id"] . "</td>";
                echo "<td>" . $baris["nama"] . "</td>";
                echo "<td>" . $baris["deskripsi"] . "</td>";
                echo "<td>" . "<form action='update_mata_pelajaran.php' method='POST'>";
                echo "<input type='submit' value='Update'>";
                echo "<input type='hidden' value='" . $baris["id"] . "' name='id'>";
                echo "</form>" . "</td>";
                echo "<td>" . "<form action='proses_hapus_mata_pelajaran.php' method='POST'>";
                echo "<input type='submit' value='Delete'>";
                echo "<input type='hidden' value='" . $baris["id"] . "' name='id'>";
                echo "</form>" . "</td>";
                echo "</tr>";
            }
        } else {
            echo "0 hasil ditemukan.";
        }
        ?>
    </table>
    <a href="main_menu.html">Kembali</a>
    <a href="tambah_mata_pelajaran.php">Tambah mapel</a>
</body>
</html>
