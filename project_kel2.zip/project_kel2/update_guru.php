<?php include "koneksi.php"; ?>
<?php
    $id = $_POST['id'];
    $sqlquery = "SELECT * FROM guru
    where id = ".$id.";";
    $hasil = $koneksi->query($sqlquery);

    if ($hasil->num_rows > 0) {
        while($data = $hasil->fetch_assoc()) {
            $nama      = $data ['nama'];
            $tanggal_lahir   = $data ['tanggal_lahir'];
            $alamat = $data ['alamat'];
       }
    }
?>

<html>
    <head>
        <title>Update Data guru ----</title>
    </head>
<body>

    <form action="proses_update_guru.php" method="POST">
        <p>id_guru    : </p> 
        <input type="numeric" name="id" value="<?php echo $id?>">
        <p>Nama           : </p>
        <input type="text" name="nama" value="<?php echo $nama?>">
        <p>tanggal_lahir           : </p>
        <input type="date" name="tanggal_lahir" value="<?php echo $tanggal_lahir?>">
        <p>alamat     : </p>
        <input type="text" name="alamat" value="<?php echo $alamat?>">

        <input type="submit" value="Update">
    </form>
</body>
</html>