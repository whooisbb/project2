<?php include "koneksi.php"; ?>
<?php
    $id = $_POST['id'];
    $sqlquery = "SELECT * FROM jadwal_pelajaran
    where id = ".$id.";";
    $hasil = $koneksi->query($sqlquery);

    if ($hasil->num_rows > 0) {
        while($data = $hasil->fetch_assoc()) {
            $id_kelas      = $data ['id_kelas'];
            $id_mata_pelajaran   = $data ['id_mata_pelajaran'];
            $id_guru = $data ['id_guru'];
            $hari = $data ['hari'];
            $jam_mulai = $data ['jam_mulai'];
            $jam_selesai = $data ['jam_selesai'];

       }
    }
?>

<html>
    <head>
        <title>Update Data Jadwal Pelajaran----</title>
    </head>
<body>

    <form action="proses_update_jadwal_pelajaran.php" method="POST">
        <p>id : </p> 
        <input type="numeric" name="id" value="<?php echo $id?>">
        <p>id kelas      : </p>
        <input type="text" name="id_kelas" value="<?php echo $id_kelas?>">
        <p>mata pelajaran           : </p>
        <input type="numeric" name="id_mata_pelajaran" value="<?php echo $id_mata_pelajaran?>">
        <p>id guru   : </p>
        <input type="numeric" name="id_guru" value="<?php echo $id_guru?>">
        <p>hari : </p>
        <input type="numeric" name="hari" value="<?php echo $hari?>">
        <p>jam mulai   : </p>
        <input type="numeric" name="jam_mulai" value="<?php echo $jam_mulai?>">
        <p>jam selesai    : </p>
        <input type="numeric" name="jam_selesai" value="<?php echo $jam_selesai?>">
        

        <input type="submit" value="Update">
    </form>
</body>
</html>