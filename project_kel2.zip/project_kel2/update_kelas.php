<?php include "koneksi.php"; ?>
<?php
    $id = $_POST['id'];
    $sqlquery = "SELECT * FROM kelas
    where id = ".$id.";";
    $hasil = $koneksi->query($sqlquery);

    if ($hasil->num_rows > 0) {
        while($data = $hasil->fetch_assoc()) {
            $id      = $data ['id'];
            $nama   = $data ['nama'];
            $tingkat = $data ['tingkat'];
       }
    }
?>

<html>
    <head>
        <title>Update Data kelas ----</title>
    </head>
<body>

    <form action="proses_update_kelas.php" method="POST">
        <p>id   : </p> 
        <input type="numeric" name="id" value="<?php echo $id?>">
        <p>Nama           : </p>
        <input type="text" name="nama" value="<?php echo $nama?>">
        <p>tingkat       : </p>
        <input type="numeric" name="tingkat" value="<?php echo $tingkat?>">

        <input type="submit" value="Update">
    </form>
</body>
</html>