<?php include "koneksi.php"; ?>
<?php
    $id = $_POST['id'];
    $sqlquery = "SELECT * FROM mata_pelajaran
    where id = ".$id.";";
    $hasil = $koneksi->query($sqlquery);

    if ($hasil->num_rows > 0) {
        while($data = $hasil->fetch_assoc()) {
            $id      = $data ['id'];
            $nama   = $data ['nama'];
            $deskripsi = $data ['deskripsi'];
       }
    }
?>

<html>
    <head>
        <title>Update Data mata pelajaran ----</title>
    </head>
<body>

    <form action="proses_update_mata_pelajaran.php" method="POST">
        <p>id   : </p> 
        <input type="numeric" name="id" value="<?php echo $id?>">
        <p>Nama           : </p>
        <input type="text" name="nama" value="<?php echo $nama?>">
        <p>deskripsi   : </p>
        <input type="numeric" name="deskripsi" value="<?php echo $deskripsi?>">

        <input type="submit" value="Update">
    </form>
</body>
</html>