<?php include "koneksi.php"; ?>
<?php
    $id = $_POST['id'];
    $sqlquery = "SELECT * FROM siswa 
    where id = ".$id.";";
    $hasil = $koneksi->query($sqlquery);

    if ($hasil->num_rows > 0) {
        while($data = $hasil->fetch_assoc()) {
            $id      = $data ['id'];
            $nama   = $data ['nama'];
            $tanggal_lahir = $data ['tanggal_lahir'];
            $alamat = $data ['alamat'];
       }
    }
?>

<html>
    <head>
        <title>Update Data siswa ----</title>
    </head>
<body>

    <form action="proses_update_siswa.php" method="POST">
        <p>id   : </p> 
        <input type="numeric" name="id" value="<?php echo $id?>">
        <p>Nama           : </p>
        <input type="text" name="nama" value="<?php echo $nama?>">
        <p>tanggal lahir   : </p>
        <input type="date" name="tanggal_lahir" value="<?php echo $tanggal_lahir?>">
        <p>alamat : </p>
        <input type="numeric" name="alamat" value="<?php echo $alamat?>">

        <input type="submit" value="Update">
    </form>
</body>
</html>